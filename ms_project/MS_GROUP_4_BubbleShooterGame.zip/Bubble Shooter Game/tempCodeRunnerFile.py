if launchbb == True:
            if newbb == None:
                newbb = Bubble(nxtbb.color)
                newbb.angle = arrow.angle

            newbb.update()
            newbb.draw()

            if newbb.rect.right >= winwdth - 5:
                newbb.angle = 180 - newbb.angle
            elif newbb.rect.left <= 5:
                newbb.angle = 180 - newbb.angle
            launchbb, newbb, score = ShootBubbles(bbarr, newbb, launchbb, score)

            fbblist = []
            for row in range(len(bbarr)):
                for col in range(len(bbarr[0])):
                    if bbarr[row][col] != blank:
                        fbblist.append(bbarr[row][col])
                        if bbarr[row][col].rect.bottom > (winhgt - arrow.rect.height - 10):
                            return score.total, 'lose'

            if len(fbblist) < 1:
                return score.total, 'win'
            gameclrlist = UpdateColourList(bbarr)
            random.shuffle(gameclrlist)
            if launchbb == False:

                nxtbb = Bubble(gameclrlist[0])
                nxtbb.rect.right = winwdth - 5
                nxtbb.rect.bottom = winhgt - 5
